

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SaveData</title>
	<script src="js/jquery.min.js" ></script>
    <script>
    $('document').ready(function()
    $('#registerformt').submit(function((
        var Name=("#name").val().trim()
        var email=("#email").val().trim()
        var address=("#address").val().trim()
if(Name==""){
    alert("Name cannot be emmty");
    return false;
}

if(email==""){
    alert("Name cannot be emmty");
    return false;
}


if(address==""){
    alert("Name cannot be emmty");
    return false;
}



});

    )};
    </script>
</head>
<body>




<h1> Add Members </h1>
<div class="container">
    <form action="" method="post" id="registerform">
@csrf
<input type="text" name = "name" id="name" placeholder="Enter name"><br><br>
<input type="email" name = "email" id="email" placeholder="Enter email"><br><br>
<input type="text" name = "address" id="address" placeholder="Enter Address"><br><br>
<button type="submit " class="btn btn-primary"  onclick="return alert('You are successfully added');">Add Members </button>

    </form>
</div>
</body>
</html>