<h1><a href="add" class="btn btn-primary">Add member</a></h1>

<h1>Members List</h1>

<table border="">
    <tr>
        <td>ID</td>
        <td>Name</td>
        <td>Email</td>
        <td>Address</td>
        <td>Operations</td>


    </tr>
    @foreach($members as $member)
<tr>
    <td>{{$member['id']}}</td>
    <td>{{$member['name']}}</td>
    <td>{{$member['email']}}</td>
    <td>{{$member['address']}}</td>
    <td><a href={{"delete/".$member['id']}} onclick="return confirm('Are you sure want to delete?');">Delete</a>
    <a href={{'edit/'.$member['id']}} onclick="return confirm('Are you sure want to edit?');">Edit</a></td>
</tr>
@endforeach
</table>
