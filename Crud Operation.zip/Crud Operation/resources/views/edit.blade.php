<h1>Update Member</h1>


<form action="/edit" method="POST">
        @csrf
        <input type="hidden" value={{$data['id']}} name='id'>
        <input type="text" name="name" value="{{$data['name']}}"><br><br>
        <input type="text" name="email" value="{{$data['email']}}"><br><br>
        <input type="text" name="address" value="{{$data['address']}}"><br><br>
        <Button type="submit">Update</Button>
</form>
