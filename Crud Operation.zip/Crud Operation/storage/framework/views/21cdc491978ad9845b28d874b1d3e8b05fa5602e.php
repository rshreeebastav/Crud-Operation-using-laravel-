<h1>Update Member</h1>


<form action="/edit" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" value=<?php echo e($data['id']); ?> name='id'>
        <input type="text" name="name" value="<?php echo e($data['name']); ?>"><br><br>
        <input type="text" name="email" value="<?php echo e($data['email']); ?>"><br><br>
        <input type="text" name="address" value="<?php echo e($data['address']); ?>"><br><br>
        <Button type="submit">Update</Button>
</form>
<?php /**PATH C:\xampp\htdocs\LARAVEL\crudd\resources\views/edit.blade.php ENDPATH**/ ?>